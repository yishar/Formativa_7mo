<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=base_yii2',
            'username' => 'root',
            'password' => '',
//             'dsn' => 'sqlsrv:server=LH001\SQLEXPRESS;database=base_yii2',
//            'username' => 'sa',
//            'password' => '123',
            'charset' => 'utf8',
        ],
'mailer' => [
        'class' => 'yii\swiftmailer\Mailer',
        'viewPath' => '@app/mailer',
        'useFileTransport' => false,
        'transport' => [
            'class' => 'Swift_SmtpTransport',
            'host' => 'smtp.gmail.com',
            'username' => 'soporte.pucese@gmail.com',
            'password' => 'nube-sol-2200',
            'port' => '587',
            'encryption' => 'tls',
                        ],
    ],
    ],
];
